from datetime import datetime
from uuid import UUID, uuid4

from pydantic import BaseModel
from sqlmodel import Field


class TimeStampMixin(BaseModel):
    created_at: datetime | None = Field(default=datetime.now(), nullable=False)
    updated_at: datetime | None = Field(default_factory=datetime.now, nullable=False)


class UUIDMixin(BaseModel):
    id: UUID | None = Field(
        default_factory=uuid4,
        primary_key=True,
    )


__all__ = ["TimeStampMixin", "UUIDMixin"]
