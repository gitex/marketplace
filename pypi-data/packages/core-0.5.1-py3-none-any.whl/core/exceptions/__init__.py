class AppError(Exception): ...


__all__ = ["AppError"]
