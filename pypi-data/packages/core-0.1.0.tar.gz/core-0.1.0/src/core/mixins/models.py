from datetime import datetime
from uuid import UUID, uuid4

from sqlmodel import Field, SQLModel


class TimeStampMixin(SQLModel):
    created_at: datetime = Field(default=datetime.now(), nullable=False)
    updated_at: datetime | None = Field(default_factory=datetime.now, nullable=False)


class UUIDMixin(SQLModel):
    id: UUID | None = Field(
        default_factory=uuid4,
        primary_key=True,
    )
